#import <Flutter/Flutter.h>

@interface ConnectivityPlusPlugin : NSObject <FlutterPlugin>
@end
